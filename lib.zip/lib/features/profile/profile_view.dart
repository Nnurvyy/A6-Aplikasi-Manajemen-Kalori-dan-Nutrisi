import 'package:flutter/material.dart';

class ProfileView extends StatefulWidget {
  const ProfileView({super.key});

  @override
  State<ProfileView> createState() => _ProfileViewState();
}

class _ProfileViewState extends State<ProfileView> {
  static const _green = Color(0xFF2E7D32);
  static const _greenLight = Color(0xFF4CAF50);
  static const _bg = Color(0xFFF4FAF4);

  String _nama = 'Nuri Rahayu';
  String _jenisKelamin = 'Perempuan';
  String _tinggi = '160';
  String _umur = '22';
  String _beratBadan = '55';

  final double _kaloriHariIni = 760;
  final double _kaloriTarget = 2000;
  final double _lemakHariIni = 28;
  final double _lemakTarget = 65;
  final double _proteinHariIni = 35;
  final double _proteinTarget = 80;
  final double _karbHariIni = 160;
  final double _karbTarget = 250;

  void _editProfil() {
    final namaCtrl = TextEditingController(text: _nama);
    String jenisKelamin = _jenisKelamin;
    final tinggiCtrl = TextEditingController(text: _tinggi);
    final umurCtrl = TextEditingController(text: _umur);
    final beratCtrl = TextEditingController(text: _beratBadan);

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder:
          (_) => StatefulBuilder(
            builder:
                (ctx, setModal) => Container(
                  padding: EdgeInsets.fromLTRB(
                    24,
                    20,
                    24,
                    MediaQuery.of(context).viewInsets.bottom + 24,
                  ),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.vertical(
                      top: Radius.circular(24),
                    ),
                  ),
                  child: SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Center(
                          child: Container(
                            width: 40,
                            height: 4,
                            decoration: BoxDecoration(
                              color: Colors.grey[300],
                              borderRadius: BorderRadius.circular(2),
                            ),
                          ),
                        ),
                        const SizedBox(height: 20),
                        const Text(
                          'Edit Profil',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w700,
                            color: Color(0xFF1A2E1A),
                          ),
                        ),
                        const SizedBox(height: 20),
                        _inputField('Nama', namaCtrl),
                        const SizedBox(height: 14),
                        const Text(
                          'Jenis Kelamin',
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            color: Color(0xFF5A7A5A),
                          ),
                        ),
                        const SizedBox(height: 8),
                        Row(
                          children:
                              ['Laki-laki', 'Perempuan'].map((g) {
                                final selected = jenisKelamin == g;
                                return Expanded(
                                  child: GestureDetector(
                                    onTap:
                                        () => setModal(() => jenisKelamin = g),
                                    child: Container(
                                      margin: EdgeInsets.only(
                                        right: g == 'Laki-laki' ? 8 : 0,
                                      ),
                                      padding: const EdgeInsets.symmetric(
                                        vertical: 12,
                                      ),
                                      decoration: BoxDecoration(
                                        color:
                                            selected
                                                ? _green
                                                : Colors.grey[100],
                                        borderRadius: BorderRadius.circular(12),
                                      ),
                                      child: Text(
                                        g,
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          fontSize: 13,
                                          fontWeight: FontWeight.w600,
                                          color:
                                              selected
                                                  ? Colors.white
                                                  : Colors.grey[600],
                                        ),
                                      ),
                                    ),
                                  ),
                                );
                              }).toList(),
                        ),
                        const SizedBox(height: 14),
                        Row(
                          children: [
                            Expanded(
                              child: _inputField(
                                'Tinggi (cm)',
                                tinggiCtrl,
                                isNumber: true,
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: _inputField(
                                'Umur',
                                umurCtrl,
                                isNumber: true,
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: _inputField(
                                'Berat (kg)',
                                beratCtrl,
                                isNumber: true,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 24),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            onPressed: () {
                              setState(() {
                                _nama =
                                    namaCtrl.text.trim().isEmpty
                                        ? _nama
                                        : namaCtrl.text.trim();
                                _jenisKelamin = jenisKelamin;
                                _tinggi =
                                    tinggiCtrl.text.trim().isEmpty
                                        ? _tinggi
                                        : tinggiCtrl.text.trim();
                                _umur =
                                    umurCtrl.text.trim().isEmpty
                                        ? _umur
                                        : umurCtrl.text.trim();
                                _beratBadan =
                                    beratCtrl.text.trim().isEmpty
                                        ? _beratBadan
                                        : beratCtrl.text.trim();
                              });
                              Navigator.pop(context);
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: _green,
                              padding: const EdgeInsets.symmetric(vertical: 14),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(14),
                              ),
                            ),
                            child: const Text(
                              'Simpan',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w700,
                                fontSize: 15,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
          ),
    );
  }

  Widget _inputField(
    String label,
    TextEditingController ctrl, {
    bool isNumber = false,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: Color(0xFF5A7A5A),
          ),
        ),
        const SizedBox(height: 6),
        TextField(
          controller: ctrl,
          keyboardType: isNumber ? TextInputType.number : TextInputType.text,
          style: const TextStyle(fontSize: 14, color: Color(0xFF1A2E1A)),
          decoration: InputDecoration(
            filled: true,
            fillColor: const Color(0xFFF4FAF4),
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 14,
              vertical: 12,
            ),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide.none,
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildHeader(),
              const SizedBox(height: 20),
              _buildNutrisiHariIni(),
              const SizedBox(height: 20),
              _buildPersonalisasiChevron(),
              const SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 24, 20, 28),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF1B5E20), Color(0xFF43A047)],
        ),
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(28)),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Profil',
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                  color: Colors.white,
                ),
              ),
              GestureDetector(
                onTap: _editProfil,
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 7,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.edit_outlined, color: Colors.white, size: 14),
                      SizedBox(width: 5),
                      Text(
                        'Edit',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white38, width: 2),
                ),
                child: const Icon(Icons.person, color: Colors.white, size: 34),
              ),
              const SizedBox(width: 16),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _nama,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '$_jenisKelamin • $_umur tahun',
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.8),
                      fontSize: 13,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    '$_beratBadan kg • $_tinggi cm',
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.8),
                      fontSize: 13,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildNutrisiHariIni() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Nutrisi Hari Ini',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: Color(0xFF1A2E1A),
            ),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Column(
              children: [
                _buildKaloriRow(),
                const SizedBox(height: 16),
                const Divider(height: 1, color: Color(0xFFE8F5E9)),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: _buildNutriMini(
                        'Protein',
                        _proteinHariIni,
                        _proteinTarget,
                        'g',
                        const Color(0xFFEF5350),
                        const Color(0xFFFFEBEE),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _buildNutriMini(
                        'Lemak',
                        _lemakHariIni,
                        _lemakTarget,
                        'g',
                        const Color(0xFFFFA726),
                        const Color(0xFFFFF3E0),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _buildNutriMini(
                        'Karbo',
                        _karbHariIni,
                        _karbTarget,
                        'g',
                        const Color(0xFF42A5F5),
                        const Color(0xFFE3F2FD),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildKaloriRow() {
    final pct = (_kaloriHariIni / _kaloriTarget).clamp(0.0, 1.0);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: const Color(0xFFE8F5E9),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(
                    Icons.local_fire_department,
                    color: _greenLight,
                    size: 16,
                  ),
                ),
                const SizedBox(width: 8),
                const Text(
                  'Kalori',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: Color(0xFF1A2E1A),
                  ),
                ),
              ],
            ),
            Text(
              '${_kaloriHariIni.toInt()} / ${_kaloriTarget.toInt()} kkal',
              style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: _green,
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        ClipRRect(
          borderRadius: BorderRadius.circular(6),
          child: LinearProgressIndicator(
            value: pct,
            minHeight: 8,
            backgroundColor: const Color(0xFFE8F5E9),
            valueColor: AlwaysStoppedAnimation<Color>(_greenLight),
          ),
        ),
        const SizedBox(height: 6),
        Text(
          'Sisa ${(_kaloriTarget - _kaloriHariIni).toInt()} kkal lagi',
          style: const TextStyle(fontSize: 12, color: Color(0xFF5A7A5A)),
        ),
      ],
    );
  }

  Widget _buildNutriMini(
    String label,
    double val,
    double target,
    String unit,
    Color color,
    Color bg,
  ) {
    final pct = (val / target).clamp(0.0, 1.0);
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        children: [
          Text(
            '${val.toInt()}$unit',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: color,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: const TextStyle(fontSize: 11, color: Color(0xFF5A7A5A)),
          ),
          const SizedBox(height: 6),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: pct,
              minHeight: 5,
              backgroundColor: Colors.white,
              valueColor: AlwaysStoppedAnimation<Color>(color),
            ),
          ),
          const SizedBox(height: 4),
          Text(
            '/ ${target.toInt()}$unit',
            style: const TextStyle(fontSize: 10, color: Color(0xFF8EBA8E)),
          ),
        ],
      ),
    );
  }

  Widget _buildPersonalisasiChevron() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Personalisasi',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: Color(0xFF1A2E1A),
            ),
          ),
          const SizedBox(height: 12),
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Column(
              children: [
                _buildChevronItem(
                  Icons.wc_rounded,
                  'Jenis Kelamin',
                  _jenisKelamin,
                  const Color(0xFFE8F5E9),
                  _greenLight,
                  isFirst: true,
                ),
                _buildDivider(),
                _buildChevronItem(
                  Icons.height_rounded,
                  'Tinggi Badan',
                  '$_tinggi cm',
                  const Color(0xFFE3F2FD),
                  const Color(0xFF42A5F5),
                ),
                _buildDivider(),
                _buildChevronItem(
                  Icons.cake_rounded,
                  'Umur',
                  '$_umur tahun',
                  const Color(0xFFFFF3E0),
                  const Color(0xFFFFA726),
                ),
                _buildDivider(),
                _buildChevronItem(
                  Icons.monitor_weight_rounded,
                  'Berat Badan',
                  '$_beratBadan kg',
                  const Color(0xFFFFEBEE),
                  const Color(0xFFEF5350),
                  isLast: true,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildChevronItem(
    IconData icon,
    String label,
    String value,
    Color iconBg,
    Color iconColor, {
    bool isFirst = false,
    bool isLast = false,
  }) {
    return GestureDetector(
      onTap: _editProfil,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(
            top: isFirst ? const Radius.circular(20) : Radius.zero,
            bottom: isLast ? const Radius.circular(20) : Radius.zero,
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: iconBg,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, color: iconColor, size: 18),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Text(
                label,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color: Color(0xFF1A2E1A),
                ),
              ),
            ),
            Text(
              value,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: Color(0xFF2E7D32),
              ),
            ),
            const SizedBox(width: 6),
            const Icon(
              Icons.chevron_right_rounded,
              color: Color(0xFF8EBA8E),
              size: 20,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDivider() {
    return const Padding(
      padding: EdgeInsets.symmetric(horizontal: 18),
      child: Divider(height: 1, color: Color(0xFFE8F5E9)),
    );
  }
}
